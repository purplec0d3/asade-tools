# FBChecker
- pip install requests
- python cekerfb.py
